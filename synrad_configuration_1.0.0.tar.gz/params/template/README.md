This directory contains the template configuration for the GSWR real time system.

The following placeholders in the configuration must be replaced before runtime.

| Placeholder | Description | Example Value |
|-|-|-|
| SW_HOME | Directory of synrad code base | /home/synrad/sw |
| PARAMS_HOME | Directory of synrad configuration | ${SW_HOME}/params/default |
| LOGS_HOME | Directory where synrad writes logs to | /home/synrad/logs |
| LOGS_SERVER_IP | IP address of server where logs are consolidated | 10.43.35.101 |
| LOGS_SERVER_PORT | Port of the server where logs are consolidated | 10412 |
|  |  |  |
| INGEST_INPUT_DIR | Directory for input data in general | /home/xfer/afwa |
| LIGHTNING_INPUT_DIR | Directory for lightning input data | /data/lightning |
| GALWEM_INPUT_DIR | Directory for GALWEM input data | /data/557/GALWEM |
| GFS_INPUT_DIR | Directory for GFS input data | /AfwDataEfs/AwsOpenData/MODEL/GFS |
| HRRR_INPUT_DIR | Directory for HRRR input data | /home/xfer/hrrr |
| MRMS_INPUT_DIR | Directory for MRMS input data | /data/NOAA/MRMS/grib2 |
| MRMS_BACKFILL_INPUT_DIR | Directory for backfill MRMS input data | /home/data/synrad/mrms_ldm |
| GOES16_INPUT_DIR | Directory for GOES-16 input data | /AfwDataEfs/AwsOpenData/METSAT/GOES-16 |
| GOES17_INPUT_DIR | Directory for GOES-17 input data | /AfwDataEfs/AwsOpenData/METSAT/GOES-17 |
| GPM_INPUT_DIR | Directory for GPM input data | /data/incoming/GPM/radar/ |
| METSAT_INPUT_DIR | Directory for METSAT input data | /data/557/METSAT |
|  |  |  |
| ARCHIVE_HOME | Directory for archive files | /data/outgoing/archives |
| GEOTIFF_OUTPUT_DIR | Directory where GEOTIFF output files are written to | /data/outgoing/sandbox/geotiff |
| FORECAST_SCORE_OUTPUT_DIR | Directory where forecast scores are written to | /home/data/synrad/wxnet/datasets/synrad/rts_scores |
| GPM_OVERLAP_ARCHIVE_DIR | Directory where GPM overlap files are archived to | /home/data/synrad/gpmOverlap |
|  |  |  |
| ARX_HOST_DEFAULT | The host name of the ARX database instance | gswrdb |
| ARX_DBNAME_DEFAULT | The ARX database name | ARX |
| ARX_USER_DEFAULT | The ARX database user | pguser |
| HISTO_HOST_DEFAULT | The host name of the HISTO database instance  | gswrdb |
| HISTO_USER_DEFAULT | The HISTO database user | pguser |
|  |  |  |
| WEB_DB_URI | The web UI database connection URI | postgresql://pguser@gswrwebdb1:5432/synrad |
| PRODUCT_UPDATE_URL | The REST endpoint where products are updated | http://gswr-webdisplay:8000/update_products/ |

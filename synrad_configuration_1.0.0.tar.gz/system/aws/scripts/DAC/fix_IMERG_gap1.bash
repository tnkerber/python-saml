#!/bin/bash
# fix_IMERG_gap1.bash

./IMERGftpDAC_by_date.bash 2019 10 04
./IMERGftpDAC_by_date.bash 2019 10 05
./IMERGftpDAC_by_date.bash 2019 10 06
./IMERGftpDAC_by_date.bash 2019 10 07
./IMERGftpDAC_by_date.bash 2019 10 08
./IMERGftpDAC_by_date.bash 2019 10 09
./IMERGftpDAC_by_date.bash 2019 10 10
./IMERGftpDAC_by_date.bash 2019 10 11
./IMERGftpDAC_by_date.bash 2019 10 12
./IMERGftpDAC_by_date.bash 2019 10 13
./IMERGftpDAC_by_date.bash 2019 10 14

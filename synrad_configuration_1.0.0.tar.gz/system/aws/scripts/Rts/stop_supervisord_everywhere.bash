#!/usr/bin/bash
#===============================================================================
#
#   (c) Copyright, 2019 Massachusetts Institute of Technology.
#
#===============================================================================
# stop_supervisord_everywhere.bash script.
# Stops supervisord on all nodes from the list. This will cause to stop all tasks started by supervisord.

m=`hostname`
filename=$1

if [ ! $m = "gswrls1" ] || [ $# -eq 0 ] || [ $1 = "-h" ] || [ $1 = "--help" ] || [ ! -r $filename ]
then
  echo USAGE: stop_supervisord_everywhere.bash node_list_file
  echo "IMPORTANT: script runs only on gswrls1. " 
  echo node_list_file -- list of all nodes to stop supervisord daemon.
exit
fi

for node in $(cat $filename) ; do
  ssh -Atq synrad@gswrls1 ssh -Atq $node bash << HERE

    hostname
    cd $LOGS_HOME/supervisor/
    pwd
    cat $node.pid | xargs kill

HERE
done

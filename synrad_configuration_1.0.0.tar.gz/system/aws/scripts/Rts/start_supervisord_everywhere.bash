#!/usr/bin/bash
#===============================================================================
#
#   (c) Copyright, 2019 Massachusetts Institute of Technology.
#
#===============================================================================
# start_supervisord_everywhere.bash script.
# Startind supervisord on all nodes from the list
# Must and will run only from gswrls1

m=`hostname`
filename=$1

if [ ! $m = "gswrpm" ] || [ $# -eq 0 ] || [ $1 = "-h" ] || [ $1 = "--help" ] || [ ! -r $filename ]
then
  echo USAGE: start_supervisord_everywhere.bash node_list_file
  echo where node_list_file -- file with list of all nodes to run supervisord daemon.
  echo "IMPORTANT: script runs only on gswrls1. " 
  exit
fi

echo "Discregard warnings from ssh"
for node in $(cat $filename) ; do
  ssh -A -t $node -q << HERE  
  sudo su - synrad < /home/synrad/sw/synrad/system/scripts/Rts/start_supervisord.bash 
HERE
done

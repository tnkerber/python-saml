#!/usr/bin/bash
#===============================================================================
#
#   (c) Copyright, 2019 Massachusetts Institute of Technology.
#
#===============================================================================
# set_Svd_tnls.bash - starts RTS cluster tunneling, to be used with supervisord.

m=`hostname`

if [ ! $m = "gswrls1" ] || [ $# -ne 0 ]
then
  echo USAGE: set_Svd_tnls.bash 
  echo "Starts all ssh tunnels on gswrls1 for all RTS nodes; tunnels are used to get html GUI of supervisord."
  echo "This script runs only on gswrls1. " 
  echo "IMPORTANT: check that tunnels not yet set up for ports: 9001-9022,9029-9032 23-28 not assigned now; 9090 and 9092 for logs and CGI."
  echo "Kill them manually if need to restart."
  exit
fi

sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9001:localhost:9001 gswrs001
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9002:localhost:9002 gswrs002
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9003:localhost:9003 gswrs003
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9004:localhost:9004 gswrs004

sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9005:localhost:9005 gswrm001
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9006:localhost:9006 gswrm002
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9007:localhost:9007 gswrm003
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9008:localhost:9008 gswrm004
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9009:localhost:9009 gswrm005
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9010:localhost:9010 gswrm006
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9011:localhost:9011 gswrm007
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9012:localhost:9012 gswrm008

sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9013:localhost:9013 gswrl001
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9014:localhost:9014 gswrl002
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9015:localhost:9015 gswrl003
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9016:localhost:9016 gswrl004
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9017:localhost:9017 gswrl005
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9018:localhost:9018 gswrl006
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9019:localhost:9019 gswrl007
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9020:localhost:9020 gswrl008

sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9021:localhost:9021 gswrxl001
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9022:localhost:9022 gswrxl002

sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9029:localhost:9029 gswrds1
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9030:localhost:9030 gswrds2
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9031:localhost:9031 gswrgs1
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9032:localhost:9032 gswrgs2
# no setting of 9033 tunnel for gswrls1 -- set just as port in svd.
# Tunnels for viewing log files and running GCI scripts
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9090:localhost:8003 gswrls1
sleep 0.1 ; ssh -q -N -f -L 127.0.0.1:9092:localhost:8000 gswrls1
